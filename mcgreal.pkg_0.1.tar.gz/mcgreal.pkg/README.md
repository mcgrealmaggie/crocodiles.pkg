# mcgreal.pkg
## An R package for processing and visualizing data obtained from multisensor animal-borne satellite trackers

This package is intended for users of custom-built multisensor satellite trackers with the purpose of visualizing and analyzing raw data of measurements collected from sensors on-board the device: GPS, Arduino IMU, and more. 
