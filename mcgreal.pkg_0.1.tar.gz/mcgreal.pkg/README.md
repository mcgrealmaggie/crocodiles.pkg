# mcgreal.pkg
## An R package for processing animal-borne satellite tracker data from various sensors onboard the device

This package is intended for users of custom-built satellite trackers with the purpose of visualizing and analyzing raw data of measurements collected from various sensors onboard the device: GPS, Arduino IMU, and more. 
